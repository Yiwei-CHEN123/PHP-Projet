<?php
   // charger le fichier des fonctions
require("Fonction_utile.php");

// executer la fonction de connexion
$cx = connexion(); 
session_start();

//$email = filter_input(INPUT_GET, "email", FILTER_SANITIZE_SPECIAL_CHARS);

?>

<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <title>La fonction principale</title>
</head>

<body>

    <p>Choisissez l'opération que vous voulez faire :</p>

    <br/>
    <?php

        $PosteE = retrouverPoste($cx,$_SESSION["email"]);
        if ($PosteE == "Directeur" or $PosteE == "Directeur Adjoint" or $PosteE == "Directeur des ventes") {
            echo '<a href="Commande.php">Faire une commande de rapport</a>';
            echo ("<br/>");
            echo '<a href="Liste_rapport.html">Consulter les rapports</a>';
        } else {
            echo '<a href="Liste_rapport.html">Consulter les rapports</a>';
        } 
        $_SESSION['Poste'] = $PosteE;
    ?>

</body>

</html>